<?php include('header.php');?>


      <section id="Home">
        <div class="container">
            <h1>NEW COLOGNES</h1>
            <h2><span>Best Prices</span> For The <span>Best Scents</span></h2>
            <p>Scentsy offers the best of the best colognes at the cheapest discounts.</p>
            <button class="shop-btn">Shop Cologne</button>
        </div>
      </section>

      <section id="brand" class="container">
        <div class="row">
            <img class="img-fluid col-lg-3 col-md-6 col-sm-12" src="assets/imgs/brand1.jpg">
            <img class="img-fluid col-lg-3 col-md-6 col-sm-12" src="assets/imgs/brand2.jpg">
            <img class="img-fluid col-lg-3 col-md-6 col-sm-12" src="assets/imgs/brand3.png">
            <img class="img-fluid col-lg-3 col-md-6 col-sm-12" src="assets/imgs/brand4.jpg">
        </div>
      </section>

      <div class="for-shop">
        <h1>Newest Products</h1>
      </div>

      <section id="new" class="container">
        <div class="row">
        <?php include('server/get_featured_products2.php')?>


        <?php while($row= $featured_products->fetch_assoc()){ ?>
            <div class="col-lg-4 col-md-4 col-sm-12">
                <img href="#" class="img-fluid" src="assets/imgs/<?php echo $row['product_image'];?>" style="height: 500px;">
                <div class="details">
                    <h5 class="p-name"><?php echo $row['product_name']?></h5>
                    <h4 class="p-price">$ <?php echo $row['product_price'];?></h4>
                    <a href="single_product.php?product_id=<?php echo $row['product_id'];?>"><button class="buy-btn">Buy Now</button></a>
                </div>
            </div>
        <?php } ?>
        </div>
    </section>
        <section id="featured" class="my-5">
            <div class="container text-center">
                <h3>More Featured</h3>
                <hr>
                <p>Check our Featured Products</p>
            </div>
            <section id="featured" class="my-5 pb-5">
                <div class="row mx-auto container-fluid">
                <?php include('server/get_featured_products3.php')?>


                <?php while($row= $featured_products->fetch_assoc()){ ?>
                    <div class="product text-center col-md-4 col-sm-12">
                        <img class="img-fluid mb-5" src="assets/imgs/<?php echo $row['product_image'];?>" width="5px">
                        <div class="stars">
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                            <i class="fas fa-star"></i>
                        </div>
                        <h5 class="p-name"><?php echo $row['product_name']?></h5>
                        <h4 class="p-price">$ <?php echo $row['product_price'];?></h4>
                        <a href="single_product.php?product_id=<?php echo $row['product_id'];?>"><button class="buy-btn">Buy Now</button></a>
                    </div>
                <?php } ?>
            
                </div>
            </section>
            
            </div>
        </section>
        
        </div>
    </section>

    <section id="banner" class="my-5 pb-5">
      <div class="container">
        <!--<h4>WINTER FRAGRANCE'S SALES</h4>
        <h1>Winter/Autumn Collection <br> <span>UP</span>to 45% <span>OFF</span></h1>
        <button class="text-uppercase">SHOP NOW</button>
      </div>-->
    </section>
    
    
    <section id="featured" class="my-5 pb-5">
      <div class="container text-center mt-5 py-5">
          <h3>Other Products</h3>
          <hr>
          <p>Check the greatest Fragrances</p>
      </div>
      <section id="featured" class="my-5">
          <div class="row mx-auto container-fluid">

          <?php include('server/get_featured_products.php')?>


          <?php while($row= $featured_products->fetch_assoc()){ ?>

              <div class="product text-center col-lg-3 col-md-4 col-sm-12">
                  <img class="img-fluid mb-5" src="assets/imgs/<?php echo $row['product_image'];?>" width="5px">
                  <div class="stars">
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                      <i class="fas fa-star"></i>
                  </div>
                  <h5 class="p-name"><?php echo $row['product_name']?></h5>
                  <h4 class="p-price">$ <?php echo $row['product_price'];?></h4>
                  <a href="single_product.php?product_id=<?php echo $row['product_id'];?>"><button class="buy-btn">Buy Now</button></a>
              </div>
              <?php } ?>
          </div>
      </section>

      <!--<section id="featured" class="my-5 pb-5">
        <div class="container text-center mt-5 py-5">
            <h3>Summer Fragrances</h3>
            <hr>
            <p>Check the greatest Summer fragrances</p>
        </div>
        <section id="featured" class="my-5">
            <div class="row mx-auto container-fluid">
                <div class="product text-center col-lg-3 col-md-4 col-sm-12">
                    <img class="img-fluid mb-5" src="assets/imgs/jpg-lebeau-leparfum.jpg" style="height: 500px;">
                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                    </div>
                    <h5 class="p-name"><#?php echo $row['product_name']?></h5>
                    <h4 class="p-price">$ <#?php echo $row['product_price']?></h4>
                    <button class="buy-btn">Buy Now</button>
                </div>
            </div>
        </section>-->
    
    
    

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

    </body>
</html>