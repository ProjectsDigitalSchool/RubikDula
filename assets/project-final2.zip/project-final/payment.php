<?php include('header.php');?>  

<?php


if(isset($_POST['order_pay_btn'])){
  $order_status = $_POST['order_status'];
  $order_total_price = $_POST['order_total_price'];
}


?>






      <section class="my-5 py-5">
        <div class="container text-center mt-3 pt-5">
            <h2 class="Text form-weight-bold">Payment</h2>
            <hr class="mx-auto">

        </div>
        <div class="mx-auto container text-center">
          <?php if(isset($_SESSION['total']) && $_SESSION['total'] != 0) { ?>
            <p>Total: $ <?php echo $_SESSION['total'];?></p>
            <input class="btn btn-primary" type="submit" value="Pay Now">
            
            <?php } elseif(isset($_POST['order_status']) && $_POST['order_status'] == "not_paid") {?>
              <p>Total: $<?php echo $_POST['order_total_price']?></p>
              <input class="btn btn-primary" type="submit" value="Pay Now">

            <?php } else { ?>

              <p>Your do not have an order</p>
            
            <?php } ?>

      </section>





    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>
</html>