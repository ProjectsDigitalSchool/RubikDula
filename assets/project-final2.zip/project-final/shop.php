<?php
include('server/connection.php');

if (isset($_POST['search'])) {
    if (isset($_GET['page_no']) && $_GET['page_no'] != "") {
        $page_no = $_GET['page_no'];
    } else {
        $page_no = 1;
    }

    $category = $_POST['category'];
    $price = $_POST['price'];

    $stmt = $conn->prepare("SELECT COUNT(*) As total_records FROM products WHERE product_category=? AND product_price<=?");
    $stmt->bind_param('si', $category, $price);
    $stmt->execute();
    $stmt->bind_result($total_records);
    $stmt->store_result();
    $stmt->fetch();

    $total_records_per_page = 8;

    $offset = ($page_no - 1) * $total_records_per_page;

    $previous_page = $page_no - 1;
    $next_page = $page_no + 1;

    $adjacents = "2";

    $total_no_of_pages = ceil($total_records / $total_records_per_page);

    $stmt2 = $conn->prepare("SELECT * FROM products WHERE product_category=? AND product_price<=? LIMIT ?, ?");
    $stmt2->bind_param("siii", $category, $price, $offset, $total_records_per_page);
    $stmt2->execute();
    $products = $stmt2->get_result();

} else {
    if (isset($_GET['page_no']) && $_GET['page_no'] != "") {
        $page_no = $_GET['page_no'];
    } else {
        $page_no = 1;
    }

    $stmt1 = $conn->prepare("SELECT COUNT(*) As total_records FROM products");
    $stmt1->execute();
    $stmt1->bind_result($total_records);
    $stmt1->store_result();
    $stmt1->fetch();

    $total_records_per_page = 8;

    $offset = ($page_no - 1) * $total_records_per_page;

    $previous_page = $page_no - 1;
    $next_page = $page_no + 1;

    $adjacents = "2";

    $total_no_of_pages = ceil($total_records / $total_records_per_page);

    $stmt2 = $conn->prepare("SELECT * FROM products LIMIT ?, ?");
    $stmt2->bind_param("ii", $offset, $total_records_per_page);
    $stmt2->execute();
    $products = $stmt2->get_result();
}
?>

<!DOCTYPE html>
<html>
<head>
    <!-- Your HTML head content here -->
</head>
<body>

<?php include('header.php'); ?>

<section id="featured" class="my-5 py-5">
    <div class="container mt-5 py-5">
        <h3>Scentsy</h3>
        <hr>
        <p>Shop for your Scent, your Fragrance</p>
    </div>
    <section id="featured" class="my-5">
        <div class="row mx-auto container-fluid">
            <?php while ($row = $products->fetch_assoc()) { ?>
                <div onclick="window.location.href='single_product.php';" class="product text-center col-lg-3 col-md-4 col-sm-12">
                    <img class="img-fluid mb-5" src="assets/imgs/<?php echo $row['product_image']; ?>" style="height: 550px;">
                    <div class="stars">
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                        <i class="fas fa-star"></i>
                    </div>
                    <h5 class="p-name"><?php echo $row['product_name']; ?></h5>
                    <h4 class="p-price">$<?php echo $row['product_price']; ?></h4>
                    <a class="btn buy-btn" href="single_product.php?product_id=<?php echo $row['product_id']; ?>">Buy Now</a>
                </div>
            <?php } ?>
            <nav aria-label="Page navigation example">
                <ul class="pagination mt-5">
                    <?php if ($page_no > 1) { ?>
                        <li class="page-item">
                            <a class="page-link" href="shop.php?page_no=<?php echo $previous_page; ?>">Previous</a>
                        </li>
                    <?php } ?>
                    <?php for ($i = max(1, $page_no - $adjacents); $i <= min($page_no + $adjacents, $total_no_of_pages); $i++) { ?>
                        <li class="page-item">
                            <a class="page-link" href="shop.php?page_no=<?php echo $i; ?>"><?php echo $i; ?></a>
                        </li>
                    <?php } ?>
                    <?php if ($page_no < $total_no_of_pages) { ?>
                        <li class="page-item">
                            <a class="page-link" href="shop.php?page_no=<?php echo $next_page; ?>">Next</a>
                        </li>
                    <?php } ?>
                </ul>
            </nav>
        </div>
    </section>
</section>

<!-- Rest of your HTML content -->

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>
</html>
